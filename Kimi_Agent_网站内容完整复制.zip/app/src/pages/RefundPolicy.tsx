import { CheckCircle, ArrowRight } from 'lucide-react';

const RefundPolicy = () => {
  const sections = [
    {
      title: '1. Refund Eligibility',
      content: `Refunds are only granted if:

• The request is made within 48 hours of purchase
• The service has not been misused or abused
• The issue is confirmed to be caused by our infrastructure
• The account is in good standing with no violations of our Terms of Service

We reserve the right to deny refund requests that do not meet these criteria.`,
    },
    {
      title: '2. Non-Refundable Services',
      content: `The following are not eligible for refunds:

• Services active for more than 48 hours
• Setup fees or custom configurations
• Free or promotional services
• Suspended services due to rule violations
• Domain registrations or third-party licenses
• Add-on services and upgrades
• Services paid with cryptocurrency

Please carefully review your order before completing the purchase.`,
    },
    {
      title: '3. Downtime & Service Issues',
      content: `No Refunds For:
• Scheduled maintenance
• Minor or temporary outages
• User-caused issues (wrong configs, deleted files, etc.)
• Issues caused by third-party software or mods

Major Failures Resolution:
For major failures caused by us, we may provide:
• Service credit equivalent to the downtime
• Extension of service period
• Partial or full refund at our discretion

Service credits are applied to your account and can be used for future purchases.`,
    },
    {
      title: '4. Refund Process',
      content: `To request a refund:

1. Contact our support team through Discord or ticket system within 48 hours of purchase.
2. Provide your order ID and reason for the refund request.
3. Our team will review your request within 24-48 hours.
4. If approved, refunds will be processed to the original payment method within 5-10 business days.

Note: Processing times may vary depending on your payment provider.`,
    },
    {
      title: '5. Chargebacks & Disputes',
      content: `We strongly encourage customers to contact us first before initiating a chargeback or payment dispute. We are committed to resolving issues amicably.

Initiating a chargeback without first contacting us may result in:
• Immediate suspension of all services
• Ban from future purchases
• Reporting to fraud databases
• Legal action in cases of fraudulent chargebacks

If you have a legitimate concern, please let us help you resolve it.`,
    },
    {
      title: '6. Special Circumstances',
      content: `In certain special circumstances, we may offer refunds beyond our standard policy:

• Prolonged service outages exceeding 24 hours
• Data loss caused by our infrastructure failures
• Billing errors on our part
• Service discontinuation

These refunds are granted at our sole discretion on a case-by-case basis.`,
    },
  ];

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="relative py-24 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-black via-[#0a0a0a] to-black" />
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-[#a3e635]/20 rounded-full blur-3xl" />
        </div>

        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center space-x-2 bg-white/5 px-4 py-2 rounded-full text-sm mb-6">
            <span className="w-2 h-2 bg-[#a3e635] rounded-full" />
            <span>Effective Date: March 24, 2026</span>
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4">
            Refund <span className="text-[#a3e635]">Policy</span>
          </h1>
          <p className="text-white/60 max-w-2xl mx-auto">
            At SnapZ Cloud, we strive for exceptional service quality. Please review our 48-hour Money-Back Guarantee and detailed refund policy below.
          </p>
        </div>
      </section>

      {/* Guarantee Banner */}
      <section className="py-8 bg-[#0a0a0a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-black border border-white/10 rounded-2xl p-6 flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-[#a3e635]/10 rounded-xl flex items-center justify-center flex-shrink-0">
                <CheckCircle className="w-6 h-6 text-[#a3e635]" />
              </div>
              <div>
                <p className="font-medium">Not completely satisfied with your new server?</p>
                <p className="text-white/60 text-sm">We'll provide a full refund if requested within 48 hours of your initial purchase.</p>
              </div>
            </div>
            <a
              href="https://discord.com/channels/1361725951607832718/1484182477697192166"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center space-x-2 bg-[#a3e635] text-black px-6 py-3 rounded-full font-semibold hover:bg-[#84cc16] transition-colors whitespace-nowrap"
            >
              <span>Request Refund</span>
              <ArrowRight className="w-4 h-4" />
            </a>
          </div>
        </div>
      </section>

      {/* Content Section */}
      <section className="py-16 bg-black">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-[#0a0a0a] border border-white/10 rounded-3xl p-8 md:p-12">
            <div className="space-y-8">
              {sections.map((section, index) => (
                <div key={index} className="border-t border-white/10 pt-8 first:border-t-0 first:pt-0">
                  <h2 className="text-xl font-bold mb-4 flex items-center">
                    <span className="text-[#a3e635] mr-2">#</span>
                    {section.title}
                  </h2>
                  <div className="text-white/60 whitespace-pre-line leading-relaxed">
                    {section.content}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default RefundPolicy;
