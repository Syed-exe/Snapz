import { useState, useEffect } from 'react';
import { CheckCircle, AlertCircle, XCircle, Clock, Server, Globe, Activity } from 'lucide-react';

const Status = () => {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setLoading(false);
    }, 1500);
    return () => clearTimeout(timer);
  }, []);

  const services = [
    { name: 'Minecraft Hosting - US West', status: 'operational', region: 'Los Angeles' },
    { name: 'Minecraft Hosting - US Central', status: 'operational', region: 'Iowa' },
    { name: 'Minecraft Hosting - US East', status: 'operational', region: 'Virginia' },
    { name: 'Minecraft Hosting - EU West', status: 'operational', region: 'Amsterdam' },
    { name: 'Minecraft Hosting - EU Central', status: 'operational', region: 'Brussels' },
    { name: 'Minecraft Hosting - Asia', status: 'operational', region: 'Mumbai' },
    { name: 'Discord Bot Hosting', status: 'operational', region: 'Global' },
    { name: 'Lavalink Nodes', status: 'operational', region: 'Global' },
    { name: 'VPS Infrastructure', status: 'operational', region: 'Global' },
    { name: 'Control Panel', status: 'operational', region: 'Global' },
    { name: 'Billing System', status: 'operational', region: 'Global' },
    { name: 'Support System', status: 'operational', region: 'Global' },
  ];

  const incidents = [
    {
      date: 'March 20, 2026',
      title: 'Scheduled Maintenance - Control Panel',
      status: 'resolved',
      description: 'Control panel will be temporarily unavailable for scheduled maintenance and updates.',
      duration: '30 minutes',
    },
    {
      date: 'March 15, 2026',
      title: 'Network Connectivity - EU West',
      status: 'resolved',
      description: 'Brief network connectivity issues affecting EU West region.',
      duration: '15 minutes',
    },
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'operational':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'degraded':
        return <AlertCircle className="w-5 h-5 text-yellow-500" />;
      case 'outage':
        return <XCircle className="w-5 h-5 text-red-500" />;
      default:
        return <Clock className="w-5 h-5 text-white/40" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'operational':
        return 'Operational';
      case 'degraded':
        return 'Degraded Performance';
      case 'outage':
        return 'Major Outage';
      default:
        return 'Unknown';
    }
  };

  if (loading) {
    return (
      <div className="pt-16 min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-[#a3e635] border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-white/60">Checking system status...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="relative py-24 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-black via-[#0a0a0a] to-black" />
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-[#a3e635]/20 rounded-full blur-3xl" />
        </div>

        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center space-x-2 bg-green-500/20 text-green-500 px-4 py-2 rounded-full text-sm mb-6">
            <CheckCircle className="w-4 h-4" />
            <span>All Systems Operational</span>
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4">
            System <span className="text-[#a3e635]">Status</span>
          </h1>
          <p className="text-white/60 max-w-2xl mx-auto">
            Real-time status of SnapZ Cloud services and infrastructure.
          </p>
        </div>
      </section>

      {/* Services Status */}
      <section className="py-16 bg-[#0a0a0a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-black border border-white/10 rounded-3xl p-8">
            <div className="flex items-center space-x-3 mb-8">
              <Server className="w-6 h-6 text-[#a3e635]" />
              <h2 className="text-xl font-bold">Services</h2>
            </div>

            <div className="space-y-4">
              {services.map((service, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-4 bg-white/5 rounded-xl"
                >
                  <div className="flex items-center space-x-4">
                    {getStatusIcon(service.status)}
                    <div>
                      <p className="font-medium">{service.name}</p>
                      <p className="text-white/40 text-sm">{service.region}</p>
                    </div>
                  </div>
                  <span className="text-sm text-green-500">{getStatusText(service.status)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Uptime Stats */}
      <section className="py-16 bg-black">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-[#0a0a0a] border border-white/10 rounded-2xl p-6 text-center">
              <Activity className="w-8 h-8 text-[#a3e635] mx-auto mb-4" />
              <p className="text-3xl font-bold text-[#a3e635]">99.998%</p>
              <p className="text-white/60 text-sm">Uptime (Last 30 Days)</p>
            </div>
            <div className="bg-[#0a0a0a] border border-white/10 rounded-2xl p-6 text-center">
              <Globe className="w-8 h-8 text-[#a3e635] mx-auto mb-4" />
              <p className="text-3xl font-bold text-[#a3e635]">6</p>
              <p className="text-white/60 text-sm">Global Locations</p>
            </div>
            <div className="bg-[#0a0a0a] border border-white/10 rounded-2xl p-6 text-center">
              <CheckCircle className="w-8 h-8 text-[#a3e635] mx-auto mb-4" />
              <p className="text-3xl font-bold text-[#a3e635]">12</p>
              <p className="text-white/60 text-sm">Services Monitored</p>
            </div>
          </div>
        </div>
      </section>

      {/* Incident History */}
      <section className="py-16 bg-[#0a0a0a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold mb-8">Recent Incidents</h2>
          
          <div className="space-y-6">
            {incidents.map((incident, index) => (
              <div
                key={index}
                className="bg-black border border-white/10 rounded-2xl p-6"
              >
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <p className="text-white/40 text-sm mb-1">{incident.date}</p>
                    <h3 className="font-bold">{incident.title}</h3>
                  </div>
                  <span className="px-3 py-1 bg-green-500/20 text-green-500 text-xs rounded-full">
                    Resolved
                  </span>
                </div>
                <p className="text-white/60 mb-4">{incident.description}</p>
                <p className="text-white/40 text-sm">
                  Duration: {incident.duration}
                </p>
              </div>
            ))}
          </div>

          {incidents.length === 0 && (
            <div className="text-center py-12 bg-black border border-white/10 rounded-2xl">
              <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
              <p className="text-white/60">No incidents reported in the last 90 days.</p>
            </div>
          )}
        </div>
      </section>

      {/* Subscribe Section */}
      <section className="py-16 bg-black">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl font-bold mb-4">Subscribe to Updates</h2>
          <p className="text-white/60 mb-8">
            Get notified when we create, update or resolve incidents.
          </p>
          <a
            href="https://discord.com/channels/1361725951607832718/1484182477697192166"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center space-x-2 bg-[#a3e635] text-black px-6 py-3 rounded-full font-semibold hover:bg-[#84cc16] transition-colors"
          >
            <span>Join Our Discord</span>
          </a>
        </div>
      </section>
    </div>
  );
};

export default Status;
