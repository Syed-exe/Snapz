import { useState } from 'react';
import { ArrowRight, Server, Check } from 'lucide-react';

const VPS = () => {
  const [cores, setCores] = useState(4);
  const [memory, setMemory] = useState(8);
  const [storage, setStorage] = useState(80);

  const price = (cores * 2 + memory * 0.5 + storage * 0.05).toFixed(2);

  const osOptions = [
    { name: 'Ubuntu', version: '24.04', icon: '🐧' },
    { name: 'Debian', version: '12', icon: '🐧' },
    { name: 'AlmaLinux', version: '9', icon: '🐧' },
    { name: 'Custom ISO', version: 'Upload', icon: '📀' },
  ];

  const features = [
    'Full root access',
    'VNC console included',
    '10Gbps unmetered bandwidth',
    'DDoS protection',
    '99.9% uptime SLA',
    '24/7 support',
  ];

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="relative min-h-[80vh] flex items-center overflow-hidden bg-[#a3e635]">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-black rounded-full blur-3xl" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center space-x-2 bg-black/10 text-black px-3 py-1 rounded-full text-sm mb-4">
                <Server className="w-4 h-4" />
                <span>Compute Instances</span>
              </div>

              <h1 className="text-5xl md:text-6xl lg:text-7xl font-black leading-tight mb-6 text-black">
                UNMETERED BARE METAL PERFORMANCE
              </h1>

              <p className="text-xl text-black/70 mb-8 max-w-lg">
                Deploy KVM VPS nodes powered by Intel Platinum 8680 processors. 10Gbps unmetered bandwidth on all instances.
              </p>

              <a
                href="https://discord.com/channels/1361725951607832718/1484182477697192166"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center space-x-2 bg-black text-white px-6 py-3 rounded-full font-semibold hover:bg-black/80 transition-colors"
              >
                <span>Deploy Now</span>
                <ArrowRight className="w-5 h-5" />
              </a>
            </div>

            {/* Resource Slider Card */}
            <div className="bg-white rounded-3xl p-8 shadow-2xl">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-black font-bold text-lg">Resource Slider</h3>
                <Server className="w-6 h-6 text-[#a3e635]" />
              </div>

              <div className="space-y-6">
                {/* CPU Cores */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-black/60 text-sm">vCPU Cores</span>
                    <span className="text-black font-bold">{cores} Cores</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="16"
                    value={cores}
                    onChange={(e) => setCores(parseInt(e.target.value))}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-[#a3e635]"
                  />
                  <div className="flex justify-between text-xs text-black/40 mt-1">
                    <span>1 Core</span>
                    <span>16 Cores</span>
                  </div>
                </div>

                {/* Memory */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-black/60 text-sm">Memory Allocation</span>
                    <span className="text-black font-bold">{memory} GB <span className="text-black/40">(DDR4 ECC)</span></span>
                  </div>
                  <input
                    type="range"
                    min="2"
                    max="64"
                    value={memory}
                    onChange={(e) => setMemory(parseInt(e.target.value))}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-[#a3e635]"
                  />
                </div>

                {/* Storage */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-black/60 text-sm">Block Storage</span>
                    <span className="text-black font-bold">{storage} GB <span className="text-black/40">(NVMe)</span></span>
                  </div>
                  <input
                    type="range"
                    min="20"
                    max="500"
                    value={storage}
                    onChange={(e) => setStorage(parseInt(e.target.value))}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-[#a3e635]"
                  />
                </div>

                {/* Network */}
                <div className="flex items-center justify-between py-3 border-t border-gray-100">
                  <span className="text-black/60 text-sm">Network Port</span>
                  <span className="text-black font-bold">10 Gbps</span>
                </div>

                <div className="flex items-center justify-between py-3 border-t border-gray-100">
                  <span className="text-black/60 text-sm">Bandwidth Transfer</span>
                  <span className="text-[#a3e635] font-bold">Unmetered</span>
                </div>

                {/* Price */}
                <div className="flex items-end justify-between pt-4 border-t border-gray-100">
                  <div>
                    <span className="text-black/40 text-sm">MONTHLY</span>
                    <div className="flex items-baseline space-x-1">
                      <span className="text-black text-2xl font-bold">$</span>
                      <span className="text-black text-4xl font-black">{price}</span>
                    </div>
                  </div>
                  <a
                    href="https://discord.com/channels/1361725951607832718/1484182477697192166"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-black text-white px-6 py-3 rounded-full font-semibold hover:bg-black/80 transition-colors"
                  >
                    Spin Up Instance
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* OS Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-12">
            <h2 className="text-4xl md:text-5xl font-black text-black mb-4">
              OS OF YOUR <span className="text-[#a3e635]">CHOICE.</span>
            </h2>
            <p className="text-black/60 max-w-2xl">
              Deploy leading Linux distributions or custom ISOs within seconds. Full root access and VNC console included standard with every KVM slice.
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-6">
            {osOptions.map((os) => (
              <div
                key={os.name}
                className="bg-gray-50 border-2 border-transparent hover:border-[#a3e635] rounded-2xl p-6 transition-all cursor-pointer"
              >
                <div className="text-4xl mb-4">{os.icon}</div>
                <h3 className="text-black font-bold text-xl mb-1">{os.name}</h3>
                <p className="text-black/60">{os.version}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-[#a3e635]/10 rounded-full flex items-center justify-center flex-shrink-0">
                  <Check className="w-4 h-4 text-[#a3e635]" />
                </div>
                <span className="text-white">{feature}</span>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default VPS;
