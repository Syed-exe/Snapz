import { useState } from 'react';
import { Search, BookOpen, ArrowRight, Gamepad2, Server, Bot } from 'lucide-react';

const Guides = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState('All');

  const filters = ['All', 'Minecraft', 'VPS', 'Discord Bots'];

  const guides = [
    {
      title: 'Minecraft Server Optimization Guide (PaperMC & Purpur)',
      description: 'Running a Minecraft server means fighting against lag and low TPS. Here is how to keep your server running at a solid 20 TPS, even with dozens of players.',
      category: 'Minecraft',
      icon: Gamepad2,
    },
    {
      title: 'Troubleshooting Low TPS & Lag Spikes',
      description: 'Is your server lagging? Are blocks breaking twice? Is the TPS dropping below 18? Here is how to find the culprit.',
      category: 'Minecraft',
      icon: Gamepad2,
    },
    {
      title: 'Essential Plugins for Every Minecraft Server',
      description: 'Regardless of your server type (SMP, Factions, Minigames), these plugins are universally recommended for administration, security, and performance.',
      category: 'Minecraft',
      icon: Gamepad2,
    },
    {
      title: 'Installing CyberPanel on Ubuntu 22.04',
      description: 'CyberPanel is the premier hosting control panel powered by OpenLiteSpeed. It natively supports WordPress, Docker, and Python applications out-of-the-box.',
      category: 'VPS',
      icon: Server,
    },
    {
      title: 'Setting up GeyserMC (Java & Bedrock Cross-play)',
      description: 'GeyserMC is a proxy that acts as a bridge, allowing players on Minecraft Bedrock Edition (Mobile, Console, Windows 10) to join a Java Edition server.',
      category: 'Minecraft',
      icon: Gamepad2,
    },
    {
      title: 'Offline Mode (Cracked) & Server Security',
      description: 'By default, Minecraft servers authenticate players against Mojang/Microsoft servers. If you set online-mode=false in your server.properties, you are running an "Offline" or "Cracked" server.',
      category: 'Minecraft',
      icon: Gamepad2,
    },
    {
      title: 'Securing your Linux VPS (SSH & Firewall)',
      description: 'The moment your VPS comes online, it is actively being scanned by automated bots trying to brute-force your password. You must secure it immediately.',
      category: 'VPS',
      icon: Server,
    },
    {
      title: 'Setting up a Java Discord Bot (JDA)',
      description: 'Java is incredibly powerful for Discord bots, handling thousands of servers easily. This guide covers deploying a JDA (Java Discord API) bot.',
      category: 'Discord Bots',
      icon: Bot,
    },
    {
      title: 'Managing Minecraft Worlds & Dimensions',
      description: 'Managing your Minecraft worlds properly is essential for preventing corruption and keeping your server fresh.',
      category: 'Minecraft',
      icon: Gamepad2,
    },
  ];

  const filteredGuides = guides.filter((guide) => {
    const matchesSearch = guide.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         guide.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = activeFilter === 'All' || guide.category === activeFilter;
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="relative py-24 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-black via-[#0a0a0a] to-black" />
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-[#a3e635]/20 rounded-full blur-3xl" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center space-x-2 bg-white/5 px-4 py-2 rounded-full text-sm mb-6">
            <BookOpen className="w-4 h-4" />
            <span>GUIDES</span>
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4">
            Learn & <span className="text-[#a3e635]">Build</span>
          </h1>
          <p className="text-white/60 max-w-2xl mx-auto">
            Everything you need to deploy, manage, and scale your projects on SnapZ Cloud.
          </p>
        </div>
      </section>

      {/* Search and Filter Section */}
      <section className="py-8 bg-[#0a0a0a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Search */}
          <div className="relative mb-6">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/40" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search guides, tutorials, or topics..."
              className="w-full bg-black border border-white/10 rounded-full py-4 pl-12 pr-4 text-white placeholder:text-white/40 focus:outline-none focus:border-[#a3e635] transition-colors"
            />
          </div>

          {/* Filters */}
          <div className="flex flex-wrap justify-center gap-2">
            {filters.map((filter) => (
              <button
                key={filter}
                onClick={() => setActiveFilter(filter)}
                className={`px-6 py-2 rounded-full text-sm font-medium transition-colors ${
                  activeFilter === filter
                    ? 'bg-[#a3e635] text-black'
                    : 'bg-white/5 text-white/60 hover:bg-white/10'
                }`}
              >
                {filter}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Guides Grid */}
      <section className="py-16 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredGuides.map((guide, index) => (
              <div
                key={index}
                className="bg-[#0a0a0a] border border-white/10 rounded-2xl p-6 hover:border-[#a3e635]/50 transition-all group"
              >
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-10 h-10 bg-[#a3e635]/10 rounded-xl flex items-center justify-center">
                    <guide.icon className="w-5 h-5 text-[#a3e635]" />
                  </div>
                  <span className="text-xs text-[#a3e635] uppercase tracking-wider">
                    {guide.category}
                  </span>
                </div>
                <h3 className="text-lg font-bold mb-3 group-hover:text-[#a3e635] transition-colors">
                  {guide.title}
                </h3>
                <p className="text-white/60 text-sm mb-4 line-clamp-3">
                  {guide.description}
                </p>
                <button className="inline-flex items-center space-x-2 text-[#a3e635] text-sm hover:underline">
                  <span>Read more</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>

          {filteredGuides.length === 0 && (
            <div className="text-center py-16">
              <p className="text-white/60">No guides found matching your search.</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default Guides;
