import { useState } from 'react';
import { CheckCircle, ArrowForward, ChevronLeft, ChevronRight, Shield, Cpu, Zap, CloudSync, LayoutDashboard, Sparkles } from 'lucide-react';

const Minecraft = () => {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'quarterly'>('monthly');
  const [currentSlide, setCurrentSlide] = useState(0);

  const plans = [
    {
      ram: '2GB',
      description: 'Perfect for small vanilla servers with friends.',
      monthlyPrice: 50,
      quarterlyPrice: 45,
      icon: '⚡',
    },
    {
      ram: '4GB',
      description: 'Great for small SMPs with essential plugins.',
      monthlyPrice: 70,
      quarterlyPrice: 63,
      icon: '🔥',
      recommended: true,
    },
    {
      ram: '8GB',
      description: 'Excellent choice for medium-sized networks.',
      monthlyPrice: 150,
      quarterlyPrice: 135,
      icon: '👻',
      recommended: true,
    },
    {
      ram: '16GB',
      description: 'Extreme performance for heavy modpacks.',
      monthlyPrice: 300,
      quarterlyPrice: 270,
      icon: '🏰',
      recommended: true,
    },
    {
      ram: '32GB',
      description: 'Unmatched hardware designed to run hubs & huge networks.',
      monthlyPrice: 550,
      quarterlyPrice: 495,
      icon: '🚀',
    },
    {
      ram: '64GB',
      description: 'The ultimate infrastructure for absolute scale.',
      monthlyPrice: 800,
      quarterlyPrice: 720,
      icon: '💎',
    },
  ];

  const features = [
    {
      icon: Shield,
      title: 'DDoS Protection',
      description: 'Enterprise-grade 480Gbps DDoS mitigation keeps your server online through the toughest attacks. We don\'t null-route; we filter bad traffic.',
    },
    {
      icon: Cpu,
      title: 'Premium Hardware',
      description: 'Powered by Ryzen 9 7950X & Core i9 14900k processors with DDR5 ECC RAM and Gen4 NVMe storage for zero-lag gameplay.',
    },
    {
      icon: Zap,
      title: 'Instant Setup',
      description: 'Your server is deployed instantly after payment. Start playing or building within seconds, with no setup fees ever.',
    },
    {
      icon: CloudSync,
      title: 'Daily Backups',
      description: 'Peace of mind included. We automatically back up your entire server daily, keeping your worlds and player data completely safe.',
    },
    {
      icon: LayoutDashboard,
      title: 'Custom Control Panel',
      description: 'Manage your server effortlessly with our custom-built, blazing fast Pterodactyl-based panel designed specifically for Minecraft.',
    },
    {
      icon: Sparkles,
      title: 'Modpack Installer',
      description: 'Install thousands of modpacks from CurseForge, Modrinth, and FTB with a single click right from your control panel.',
    },
  ];

  const additionalFeatures = [
    { icon: Cpu, title: 'Premium Hardware', description: 'High clock CPUs with optimized single-core performance for Minecraft ticks.' },
    { icon: Shield, title: 'Advanced Protection', description: 'Layered DDoS mitigation and secure panel access across every node.' },
    { icon: Zap, title: '1-Click Deploy', description: 'Spin up vanilla, modded, or plugin setups in minutes with instant provisioning.' },
  ];

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="relative min-h-[80vh] flex items-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/images/hero-minecraft.jpg"
            alt="Minecraft Hosting"
            className="w-full h-full object-cover opacity-50"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#030803] via-[#030803]/90 to-transparent" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="flex items-center mb-6">
                <span className="text-yellow-400 text-sm font-medium">Excellent</span>
                <div className="flex ml-2">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <svg key={i} className="h-4 w-4 text-green-500 fill-green-500" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
                <span className="ml-2 text-gray-400 text-sm">Trustpilot</span>
                <span className="ml-2 px-2 py-0.5 bg-green-500/20 text-green-400 text-xs rounded">verified</span>
              </div>

              <span className="inline-flex items-center px-4 py-2 bg-[#1a221a] rounded-full text-sm text-[#a3e635] mb-4">
                <CheckCircle className="h-4 w-4 mr-2" />
                JAVA EDITION OPTIMIZED
              </span>

              <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
                Minecraft: Java Edition Server Hosting
              </h1>

              <div className="grid sm:grid-cols-2 gap-3 mb-8">
                {[
                  'Always Online Game Servers',
                  '24/7 Livechat and Ticket Support',
                  'Full FTP File Access',
                  'Automatic Backups and Updates',
                  'Advanced DDoS Protection',
                  'Premium Hardware and Low Latency',
                  'Instantly Online',
                ].map((feature) => (
                  <div key={feature} className="flex items-center text-gray-300">
                    <CheckCircle className="h-4 w-4 text-[#a3e635] mr-2 flex-shrink-0" />
                    <span className="text-sm">{feature}</span>
                  </div>
                ))}
              </div>

              <div className="flex flex-wrap gap-4">
                <a
                  href="#plans"
                  className="inline-flex items-center px-6 py-3 bg-[#a3e635] text-[#030803] rounded-full font-semibold hover:bg-[#8ed62a] transition-colors"
                >
                  View Plans
                  <svg className="ml-2 h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                  </svg>
                </a>
                <a
                  href="https://discord.com/channels/1361725951607832718/1484182477697192166"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center px-6 py-3 border border-[#1f291f] text-white rounded-full font-semibold hover:bg-[#1a221a] transition-colors"
                >
                  Start Now
                  <ArrowForward className="ml-2 h-4 w-4" />
                </a>
              </div>
            </div>

            <div className="hidden lg:block">
              <img
                src="/images/hero-minecraft.jpg"
                alt="Minecraft Server"
                className="rounded-2xl shadow-2xl shadow-[#a3e635]/20"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="plans" className="py-24 bg-[#030803]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-center justify-between mb-12">
            <div className="flex items-center text-gray-400 text-sm mb-4 sm:mb-0">
              <svg className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              Monthly pricing shown
            </div>
            <div className="flex items-center bg-[#1a221a] rounded-full p-1">
              <button
                onClick={() => setBillingCycle('monthly')}
                className={`px-6 py-2 rounded-full text-sm font-medium transition-colors ${
                  billingCycle === 'monthly' ? 'bg-[#a3e635] text-[#030803]' : 'text-gray-400'
                }`}
              >
                Monthly
              </button>
              <button
                onClick={() => setBillingCycle('quarterly')}
                className={`px-6 py-2 rounded-full text-sm font-medium transition-colors ${
                  billingCycle === 'quarterly' ? 'bg-[#a3e635] text-[#030803]' : 'text-gray-400'
                }`}
              >
                Quarterly
                <span className="ml-1 text-xs">-10%</span>
              </button>
            </div>
          </div>

          <div className="relative">
            <div className="flex overflow-x-auto pb-4 gap-6 snap-x">
              {plans.map((plan, index) => (
                <div
                  key={plan.ram}
                  className={`flex-shrink-0 w-72 bg-[#0a120a] border rounded-2xl p-6 relative snap-center ${
                    plan.recommended ? 'border-[#a3e635]' : 'border-[#1f291f]'
                  }`}
                >
                  {plan.recommended && (
                    <span className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 bg-[#a3e635] text-[#030803] text-xs font-bold rounded-full">
                      Recommended!
                    </span>
                  )}
                  <div className="text-3xl mb-4">{plan.icon}</div>
                  <div className="flex items-baseline mb-2">
                    <span className="text-3xl font-bold text-[#a3e635]">{plan.ram}</span>
                    <span className="ml-2 text-gray-400">RAM</span>
                  </div>
                  <p className="text-gray-400 text-sm mb-6">{plan.description}</p>
                  <div className="mb-6">
                    <div className="flex items-baseline">
                      <span className="text-2xl font-bold">₹{billingCycle === 'monthly' ? plan.monthlyPrice : plan.quarterlyPrice}</span>
                      <span className="ml-2 text-gray-400 text-sm">first month</span>
                    </div>
                    <div className="text-gray-500 text-xs mt-1">
                      Recurring Price ₹{billingCycle === 'monthly' ? plan.monthlyPrice : plan.quarterlyPrice}
                    </div>
                    <div className="text-gray-500 text-xs">Billed {billingCycle}</div>
                  </div>
                  <a
                    href="https://discord.com/channels/1361725951607832718/1484182477697192166"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full flex items-center justify-center px-4 py-3 bg-[#1a221a] border border-[#1f291f] rounded-xl text-white font-medium hover:bg-[#a3e635] hover:text-[#030803] hover:border-[#a3e635] transition-colors"
                  >
                    Order
                    <ArrowForward className="ml-2 h-4 w-4" />
                  </a>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-[#0a120a]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Why Choose <span className="gradient-text">SnapZ Cloud</span>
            </h2>
            <p className="text-gray-400">
              Built for <span className="text-[#a3e635]">Performance</span>
            </p>
            <p className="text-gray-400 max-w-3xl mx-auto mt-4">
              We provide the ultimate Minecraft hosting experience. From unparalleled hardware power to our custom-built management tools, everything is optimized for your community's success.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature) => (
              <div
                key={feature.title}
                className="bg-[#0a120a] border border-[#1f291f] rounded-xl p-6 hover:border-[#a3e635] transition-colors"
              >
                <feature.icon className="h-10 w-10 text-[#a3e635] mb-4" />
                <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-400 text-sm">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Additional Features */}
      <section className="py-24 bg-[#030803]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-[#0a120a] border border-[#1f291f] rounded-2xl p-8">
            <div className="grid lg:grid-cols-2 gap-8 items-center">
              <div>
                <img
                  src="/images/hero-minecraft.jpg"
                  alt="Minecraft Features"
                  className="rounded-xl"
                />
              </div>
              <div>
                <div className="space-y-6">
                  {additionalFeatures.map((feature) => (
                    <div key={feature.title} className="flex items-start">
                      <div className="w-12 h-12 bg-[#1a221a] rounded-xl flex items-center justify-center mr-4 flex-shrink-0">
                        <feature.icon className="h-6 w-6 text-[#a3e635]" />
                      </div>
                      <div>
                        <h3 className="font-semibold mb-1">{feature.title}</h3>
                        <p className="text-gray-400 text-sm">{feature.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Minecraft;
