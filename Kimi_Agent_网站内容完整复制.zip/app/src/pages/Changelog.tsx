import { useState } from 'react';
import { Plus, RotateCcw, Wrench, X, RefreshCw } from 'lucide-react';

const Changelog = () => {
  const [activeFilter, setActiveFilter] = useState('All Changes');

  const filters = [
    { name: 'All Changes', icon: RefreshCw },
    { name: 'Added', icon: Plus },
    { name: 'Changed', icon: RotateCcw },
    { name: 'Fixed', icon: Wrench },
    { name: 'Removed', icon: X },
  ];

  const changelog = [
    {
      version: 'v2.5.1',
      type: 'Changed',
      date: 'Mar 20, 2026',
      title: 'Migration Data & Sync Server',
      description: 'Migrated user data from Panel and Sync server',
    },
    {
      version: 'vv2.5.0',
      type: 'Added',
      date: 'Mar 5, 2026',
      title: 'Admin Panel & Content Management',
      description: 'Added new Admin pages for managing the About Us content, Documentation, and Changelogs dynamically. Also updated navigation routes across the platform.',
    },
    {
      version: 'vv2.3.0',
      type: 'Changed',
      date: 'Mar 4, 2026',
      title: 'Services Dashboard Revamp',
      description: 'A massive visual upgrade to the user dashboard. - Improved category filters - Updated server icons for Minecraft & Discord - Refined responsive service cards',
    },
    {
      version: 'v2.2.0',
      type: 'Added',
      date: 'Feb 28, 2026',
      title: 'New Payment Gateway Integration',
      description: 'Added support for additional payment methods including UPI, PayPal, and cryptocurrency options.',
    },
    {
      version: 'v2.1.5',
      type: 'Fixed',
      date: 'Feb 20, 2026',
      title: 'Server Backup Issues Resolved',
      description: 'Fixed intermittent backup failures and improved backup retention policies.',
    },
    {
      version: 'v2.1.0',
      type: 'Added',
      date: 'Feb 15, 2026',
      title: 'Lavalink Node Expansion',
      description: 'Added new Lavalink nodes in Europe and Asia regions for better audio streaming performance.',
    },
    {
      version: 'v2.0.0',
      type: 'Changed',
      date: 'Feb 1, 2026',
      title: 'Platform Wide UI Update',
      description: 'Complete redesign of the user interface with improved navigation, dark mode enhancements, and better mobile responsiveness.',
    },
  ];

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'Added':
        return 'bg-green-500/20 text-green-500';
      case 'Changed':
        return 'bg-blue-500/20 text-blue-500';
      case 'Fixed':
        return 'bg-orange-500/20 text-orange-500';
      case 'Removed':
        return 'bg-red-500/20 text-red-500';
      default:
        return 'bg-white/10 text-white';
    }
  };

  const filteredChangelog = activeFilter === 'All Changes'
    ? changelog
    : changelog.filter((item) => item.type === activeFilter);

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="relative py-24 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-black via-[#0a0a0a] to-black" />
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-[#a3e635]/20 rounded-full blur-3xl" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center space-x-2 bg-white/5 px-4 py-2 rounded-full text-sm mb-6">
            <RefreshCw className="w-4 h-4" />
            <span>What's New</span>
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4">
            Change <span className="text-[#a3e635]">log</span>
          </h1>
          <p className="text-white/60 max-w-2xl mx-auto">
            Track every improvement, fix, and new feature shipped to SnapZ Cloud.
          </p>
        </div>
      </section>

      {/* Filter Section */}
      <section className="py-8 bg-[#0a0a0a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-2">
            {filters.map((filter) => (
              <button
                key={filter.name}
                onClick={() => setActiveFilter(filter.name)}
                className={`inline-flex items-center space-x-2 px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  activeFilter === filter.name
                    ? 'bg-[#a3e635] text-black'
                    : 'bg-white/5 text-white/60 hover:bg-white/10'
                }`}
              >
                <filter.icon className="w-4 h-4" />
                <span>{filter.name}</span>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Changelog Timeline */}
      <section className="py-16 bg-black">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-white/10" />

            <div className="space-y-8">
              {filteredChangelog.map((item, index) => (
                <div key={index} className="relative pl-12">
                  {/* Timeline Dot */}
                  <div className={`absolute left-2 top-4 w-4 h-4 rounded-full border-2 border-black ${
                    item.type === 'Added' ? 'bg-green-500' :
                    item.type === 'Changed' ? 'bg-blue-500' :
                    item.type === 'Fixed' ? 'bg-orange-500' :
                    'bg-red-500'
                  }`} />

                  {/* Content Card */}
                  <div className="bg-[#0a0a0a] border border-white/10 rounded-2xl p-6">
                    <div className="flex flex-wrap items-center gap-3 mb-3">
                      <span className="px-3 py-1 bg-[#a3e635]/20 text-[#a3e635] text-xs font-mono rounded-full">
                        {item.version}
                      </span>
                      <span className={`px-3 py-1 text-xs rounded-full ${getTypeColor(item.type)}`}>
                        {item.type}
                      </span>
                      <span className="text-white/40 text-sm ml-auto">{item.date}</span>
                    </div>
                    <h3 className="text-lg font-bold mb-2">{item.title}</h3>
                    <p className="text-white/60 text-sm">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {filteredChangelog.length === 0 && (
            <div className="text-center py-16">
              <p className="text-white/60">No changes found for this filter.</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default Changelog;
