import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowUpRight,
  ChevronLeft,
  ChevronRight,
  Check,
  Star,
  StarHalf,
  Settings,
  Database,
  ToyBrick,
  Puzzle,
  ArrowRightLeft,
  Globe,
  Zap,
  Shield,
  Clock,
  Headphones,
  Users,
  MessageSquare,
  BookOpen,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  Rocket,
  Sparkles,
  Book,
} from 'lucide-react';

const Home = () => {
  const [selectedGame, setSelectedGame] = useState('Minecraft');
  const [activeFaq, setActiveFaq] = useState<number | null>(null);
  const [currentTestimonial, setCurrentTestimonial] = useState(0);

  const games = [
    { name: 'Minecraft', icon: '🎮', soon: false },
    { name: 'Lavalink', icon: '🎵', soon: false },
    { name: 'Discord Bots', icon: '🤖', soon: false },
    { name: 'Hytale', icon: '⚔️', soon: true },
    { name: 'Terraria', icon: '🌍', soon: true },
  ];

  const pricingPlans = [
    {
      name: 'Spark',
      ram: '2GB',
      price: 50,
      originalPrice: 75,
      description: 'Unlimited slots | 2GB Ram | 30 Days',
    },
    {
      name: 'Blaze',
      ram: '4GB',
      price: 70,
      originalPrice: 105,
      description: 'Unlimited slots | 4GB Ram | 30 Days',
    },
    {
      name: 'Phantom',
      ram: '8GB',
      price: 150,
      originalPrice: 225,
      description: 'Unlimited slots | 8GB Ram | 30 Days',
    },
  ];

  const testimonials = [
    { name: 'Vikram Singh', role: 'Community Manager', text: 'With SnapZ Cloud global locations, my gaming community gets world-class latency.', initials: 'VS' },
    { name: 'Neha Patel', role: 'Discord Bot Developer', text: 'This is the most reliable service for bot hosting. The uptime guarantee is excellent.', initials: 'NP' },
    { name: 'Rohit Das', role: 'Startup Founder', text: 'Pricing for premium features is very reasonable. I have no regrets upgrading from free hosting.', initials: 'RD' },
    { name: 'Anjali Mishra', role: 'Website Owner', text: 'SnapZ Cloud support is always responsive. Most issues are resolved within 30 minutes.', initials: 'AM' },
    { name: 'Karan Malhotra', role: 'Bot Creator', text: 'Lavalink hosting quality for music bots is excellent. We have experienced near-zero downtime.', initials: 'KM' },
    { name: 'Deepak Kumar', role: 'Server Admin', text: 'Server migration with SnapZ Cloud was quick and straightforward.', initials: 'DK' },
    { name: 'Shreya Gupta', role: 'Modpack Creator', text: 'Minecraft modpack hosting on SnapZ Cloud is very stable. Performance is outstanding.', initials: 'SG' },
    { name: 'Raj Patel', role: 'Gaming Server Owner', text: 'With built-in DDoS protection, our gaming experience is worry-free.', initials: 'RP' },
    { name: 'Mohan Reddy', role: 'Tech Enthusiast', text: 'The India-based support team is fast and helpful. Communication is smooth and practical.', initials: 'MR' },
    { name: 'Zara Khan', role: 'Content Creator', text: 'I started on the free tier and upgraded to premium. The journey has been amazing.', initials: 'ZK' },
    { name: 'Suresh Iyer', role: 'Web Developer', text: 'Website hosting with SnapZ Cloud is both affordable and reliable.', initials: 'SI' },
    { name: 'Harsh Verma', role: 'Gaming Influencer', text: 'I could not find a better option for game servers. Completely satisfied.', initials: 'HV' },
  ];

  const faqs = [
    { question: 'How fast will my server be ready after payment?', answer: 'Your server is deployed instantly after payment confirmation. You can start using it within seconds.' },
    { question: 'Can I upload my existing world, files, or backups?', answer: 'Yes! You have full FTP/SFTP access to upload your existing worlds, files, and backups.' },
    { question: 'Do you provide DDoS protection?', answer: 'Yes, we provide enterprise-grade 480Gbps DDoS protection on all our servers at no extra cost.' },
    { question: 'Can I upgrade RAM, CPU, or storage later?', answer: 'Absolutely! You can upgrade your server resources anytime through our control panel.' },
    { question: 'What locations are available for lower ping?', answer: 'We have servers in Los Angeles, Iowa, Virginia, Amsterdam, Brussels, and Mumbai.' },
    { question: 'Do I get full control panel access?', answer: 'Yes, you get full access to our custom Pterodactyl-based control panel.' },
    { question: 'Is support available if something breaks?', answer: 'Our support team is available 24/7 via Discord and tickets to help you with any issues.' },
    { question: 'What is your refund policy?', answer: 'We offer a 48-hour money-back guarantee if you are not satisfied with our service.' },
  ];

  const locations = [
    { name: 'Los Angeles', country: 'US', flag: '🇺🇸' },
    { name: 'Iowa', country: 'US', flag: '🇺🇸' },
    { name: 'Virginia', country: 'US', flag: '🇺🇸' },
    { name: 'Amsterdam', country: 'NL', flag: '🇳🇱' },
    { name: 'Brussels', country: 'BE', flag: '🇧🇪' },
    { name: 'Mumbai', country: 'IN', flag: '🇮🇳' },
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="/images/home-hero.jpg"
            alt="Hero Background"
            className="w-full h-full object-cover opacity-60"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#030803] via-[#030803]/80 to-transparent" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="max-w-2xl">
            <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
              One Platform for All Your{' '}
              <span className="gradient-text">Hosting Needs</span>
            </h1>
            <p className="text-xl text-gray-300 mb-8">
              Minecraft servers, powerful VPS, Discord bots, Lavalink nodes, and web hosting — all on high-performance infrastructure.
            </p>
            <div className="flex flex-wrap gap-4">
              <a
                href="https://discord.com/channels/1361725951607832718/1484182477697192166"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center px-8 py-4 bg-[#a3e635] text-[#030803] rounded-full font-semibold hover:bg-[#8ed62a] transition-colors btn-shine"
              >
                Rent Server
                <ArrowUpRight className="ml-2 h-5 w-5" />
              </a>
              <Link
                to="/minecraft"
                className="inline-flex items-center px-8 py-4 border border-[#1f291f] text-white rounded-full font-semibold hover:bg-[#1a221a] transition-colors"
              >
                Explore Features
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Plans Section */}
      <section className="py-24 bg-[#030803]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="inline-flex items-center px-4 py-2 bg-[#1a221a] rounded-full text-sm text-[#a3e635] mb-4">
              <span className="w-2 h-2 bg-[#a3e635] rounded-full mr-2" />
              PRICING PLANS
            </span>
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Choose Your <span className="gradient-text">Perfect Plan</span>
            </h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              High-performance servers at unbeatable prices. Pick the plan that fits your needs and scale anytime.
            </p>
          </div>

          {/* Trust Badges */}
          <div className="flex flex-wrap justify-center items-center gap-6 mb-12">
            <div className="flex items-center text-gray-400 text-sm">
              <Check className="h-4 w-4 text-[#a3e635] mr-2" />
              Stripe Climate Member
            </div>
            <div className="flex items-center">
              <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
              <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
              <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
              <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
              <StarHalf className="h-4 w-4 text-yellow-400 fill-yellow-400" />
              <span className="ml-2 text-gray-400 text-sm">4.5 out of 5 based on 300+ reviews</span>
            </div>
          </div>

          {/* Minecraft Server Hosting Card */}
          <div className="bg-[#0a120a] border border-[#1f291f] rounded-2xl p-8 mb-12">
            <div className="grid lg:grid-cols-2 gap-8 items-center">
              <div>
                <div className="flex items-center mb-4">
                  <span className="text-3xl mr-3">🎮</span>
                  <span className="text-[#a3e635] font-semibold">Minecraft</span>
                </div>
                <h3 className="text-3xl font-bold mb-4">Minecraft Server Hosting</h3>
                <p className="text-gray-400 mb-6">
                  Launch the best Minecraft server hosting powered by high-performance processors. Enjoy 24/7 expert support, automatic backups, and DDoS protection.
                </p>
                <Link
                  to="/minecraft"
                  className="inline-flex items-center text-[#a3e635] hover:underline"
                >
                  View all plans
                  <ArrowUpRight className="ml-2 h-4 w-4" />
                </Link>
              </div>
              <div className="grid sm:grid-cols-3 gap-4">
                {pricingPlans.map((plan) => (
                  <a
                    key={plan.name}
                    href="https://discord.com/channels/1361725951607832718/1484182477697192166"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-[#1a221a] border border-[#1f291f] rounded-xl p-4 hover:border-[#a3e635] transition-colors"
                  >
                    <div className="flex items-center mb-2">
                      <span className="text-2xl mr-2">🎮</span>
                      <span className="font-semibold">{plan.name}</span>
                    </div>
                    <p className="text-xs text-gray-400 mb-3">{plan.description}</p>
                    <div className="flex items-baseline">
                      <span className="text-xs text-gray-500 line-through mr-2">₹{plan.originalPrice}</span>
                      <span className="text-2xl font-bold text-[#a3e635]">₹{plan.price}</span>
                    </div>
                    <span className="text-xs text-gray-400">/ Month</span>
                  </a>
                ))}
              </div>
            </div>
          </div>

          {/* Game Selector */}
          <div className="bg-[#0a120a] border border-[#1f291f] rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center">
                <Rocket className="h-5 w-5 text-[#a3e635] mr-2" />
                <span className="text-gray-400">View all</span>
                <span className="ml-2 text-[#a3e635] font-bold">{games.length}</span>
                <span className="text-gray-400 ml-1">games</span>
              </div>
              <div className="flex space-x-2">
                <button className="p-2 rounded-lg bg-[#1a221a] text-gray-400 hover:text-white">
                  <ChevronLeft className="h-5 w-5" />
                </button>
                <button className="p-2 rounded-lg bg-[#1a221a] text-gray-400 hover:text-white">
                  <ChevronRight className="h-5 w-5" />
                </button>
              </div>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
              {games.map((game) => (
                <button
                  key={game.name}
                  onClick={() => !game.soon && setSelectedGame(game.name)}
                  className={`relative p-4 rounded-xl border transition-all ${
                    selectedGame === game.name
                      ? 'border-[#a3e635] bg-[#1a221a]'
                      : 'border-[#1f291f] bg-[#0a120a] hover:border-[#2a3a2a]'
                  }`}
                >
                  <div className="text-3xl mb-2">{game.icon}</div>
                  <div className="text-sm font-medium">{game.name}</div>
                  {game.soon && (
                    <span className="absolute top-2 right-2 px-2 py-0.5 bg-gray-700 text-xs rounded-full">
                      Soon
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Panel Features Section */}
      <section className="py-24 bg-[#0a120a]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="inline-flex items-center px-4 py-2 bg-[#1a221a] rounded-full text-sm text-[#a3e635] mb-4">
              <span className="w-2 h-2 bg-[#a3e635] rounded-full mr-2" />
              PANEL FEATURES
            </span>
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Control Panel Experience That Feels <span className="gradient-text">Premium</span>
            </h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Advanced tools for mods, plugins, configs, and versions packed into one fast interface.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: Settings, title: 'Configs', desc: 'Manage server configurations easily' },
              { icon: Database, title: 'Datapacks', desc: 'Install and manage datapacks' },
              { icon: ToyBrick, title: 'Mods', desc: 'One-click mod installation' },
              { icon: Puzzle, title: 'Plugins', desc: 'Browse and install plugins' },
              { icon: ArrowRightLeft, title: 'Versions', desc: 'Switch between versions' },
            ].map((feature) => (
              <div
                key={feature.title}
                className="bg-[#1a221a] border border-[#1f291f] rounded-xl p-6 hover:border-[#a3e635] transition-colors cursor-pointer"
              >
                <feature.icon className="h-8 w-8 text-[#a3e635] mb-4" />
                <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-400 text-sm">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Global Network Section */}
      <section className="py-24 bg-[#030803]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="inline-flex items-center px-4 py-2 bg-[#1a221a] rounded-full text-sm text-[#a3e635] mb-4">
              <span className="w-2 h-2 bg-[#a3e635] rounded-full mr-2" />
              GLOBAL REACH
            </span>
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Global Low Latency <span className="gradient-text">Network</span>
            </h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Choose a location near your players for the absolute lowest ping and the smoothest gameplay experience.
            </p>
          </div>

          <div className="bg-[#0a120a] border border-[#1f291f] rounded-2xl p-8">
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {locations.map((location) => (
                <div
                  key={location.name}
                  className="flex items-center p-4 bg-[#1a221a] rounded-xl"
                >
                  <span className="text-2xl mr-3">{location.flag}</span>
                  <div>
                    <div className="font-semibold">{location.name}</div>
                    <div className="text-sm text-gray-400">{location.country}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-24 bg-[#0a120a]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              What Our <span className="gradient-text">Customers</span> Say
            </h2>
          </div>

          <div className="relative overflow-hidden">
            <div className="flex transition-transform duration-500" style={{ transform: `translateX(-${currentTestimonial * 100}%)` }}>
              {testimonials.map((testimonial, index) => (
                <div
                  key={index}
                  className="w-full flex-shrink-0 px-4"
                >
                  <div className="max-w-3xl mx-auto text-center">
                    <div className="w-16 h-16 bg-[#1a221a] rounded-full flex items-center justify-center mx-auto mb-6">
                      <span className="text-xl font-bold text-[#a3e635]">{testimonial.initials}</span>
                    </div>
                    <p className="text-xl md:text-2xl text-gray-300 mb-6">"{testimonial.text}"</p>
                    <div className="font-semibold">{testimonial.name}</div>
                    <div className="text-gray-400 text-sm">{testimonial.role}</div>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex justify-center mt-8 space-x-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentTestimonial(index)}
                  className={`w-2 h-2 rounded-full transition-colors ${
                    currentTestimonial === index ? 'bg-[#a3e635]' : 'bg-[#1f291f]'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Core Infrastructure Section */}
      <section className="py-24 bg-[#030803]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="inline-flex items-center px-4 py-2 bg-[#1a221a] rounded-full text-sm text-[#a3e635] mb-4">
              <span className="w-2 h-2 bg-[#a3e635] rounded-full mr-2" />
              CORE INFRASTRUCTURE
            </span>
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Everything You Need to <span className="gradient-text">Dominate</span>
            </h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Built from the ground up for superior performance and undeniable reliability.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: Zap, title: 'Instant Setup', desc: 'Deploy in seconds' },
              { icon: Database, title: 'NVMe Power', desc: 'Lightning-fast storage' },
              { icon: Clock, title: 'Auto Backups', desc: 'Daily automated backups' },
              { icon: Globe, title: '99.9% Uptime', desc: 'Guaranteed availability' },
              { icon: Shield, title: 'DDoS Guard', desc: 'Enterprise protection' },
              { icon: Headphones, title: 'Pro Support', desc: '24/7 expert help' },
            ].map((item) => (
              <div
                key={item.title}
                className="bg-[#0a120a] border border-[#1f291f] rounded-xl p-6 text-center hover:border-[#a3e635] transition-colors"
              >
                <item.icon className="h-10 w-10 text-[#a3e635] mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">{item.title}</h3>
                <p className="text-gray-400 text-sm">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-24 bg-[#0a120a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <span className="inline-flex items-center px-4 py-2 bg-[#1a221a] rounded-full text-sm text-[#a3e635] mb-4">
              <span className="w-2 h-2 bg-[#a3e635] rounded-full mr-2" />
              SUPPORT HUB
            </span>
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Frequently Asked <span className="gradient-text">Questions</span>
            </h2>
            <p className="text-gray-400">
              Everything you need before you deploy
            </p>
          </div>

          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div
                key={index}
                className="bg-[#0a120a] border border-[#1f291f] rounded-xl overflow-hidden"
              >
                <button
                  onClick={() => setActiveFaq(activeFaq === index ? null : index)}
                  className="w-full flex items-center justify-between p-6 text-left"
                >
                  <span className="font-medium">{faq.question}</span>
                  {activeFaq === index ? (
                    <ChevronUp className="h-5 w-5 text-[#a3e635]" />
                  ) : (
                    <ChevronDown className="h-5 w-5 text-gray-400" />
                  )}
                </button>
                {activeFaq === index && (
                  <div className="px-6 pb-6 text-gray-400">
                    {faq.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Support Hub Section */}
      <section className="py-24 bg-[#030803]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Need help?</h2>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: Users, title: 'Discord Community', desc: 'Connect with fellow gamers, get quick support, and stay updated on news and events.', link: 'https://discord.gg/MsvNYeQxCa', linkText: 'Join Now' },
              { icon: Headphones, title: 'Live Support', desc: 'Real-time chat with our team for billing and technical questions.', link: '#', linkText: 'Coming Soon', disabled: true },
              { icon: HelpCircle, title: 'FAQs', desc: 'View common answers for setup, upgrades, backups, and general hosting questions.', link: '#faq', linkText: 'Learn More' },
              { icon: BookOpen, title: 'Guides', desc: 'Stay up to date with the latest guides and tutorials for smoother server management.', link: '/guides', linkText: 'Learn More' },
            ].map((item) => (
              <div
                key={item.title}
                className="bg-[#0a120a] border border-[#1f291f] rounded-xl p-6 hover:border-[#a3e635] transition-colors"
              >
                <item.icon className="h-8 w-8 text-[#a3e635] mb-4" />
                <h3 className="text-lg font-semibold mb-2">{item.title}</h3>
                <p className="text-gray-400 text-sm mb-4">{item.desc}</p>
                {item.disabled ? (
                  <span className="inline-flex items-center px-3 py-1 bg-[#1a221a] rounded-full text-xs text-gray-500">
                    Coming Soon
                  </span>
                ) : (
                  <Link
                    to={item.link}
                    className="inline-flex items-center text-[#a3e635] text-sm hover:underline"
                  >
                    {item.linkText}
                    <ArrowUpRight className="ml-1 h-4 w-4" />
                  </Link>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Our Journey Section */}
      <section className="py-24 bg-[#0a120a]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <span className="inline-flex items-center px-4 py-2 bg-[#1a221a] rounded-full text-sm text-[#a3e635] mb-4">
                <Sparkles className="h-4 w-4 mr-2" />
                OUR JOURNEY
              </span>
              <h2 className="text-4xl md:text-5xl font-bold mb-6">
                The Story Behind <span className="gradient-text">SnapZ Cloud</span>
              </h2>
              <p className="text-gray-400 mb-6">
                Built for performance, designed for ambitious developers and growing communities.
              </p>

              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="w-10 h-10 bg-[#1a221a] rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                    <Book className="h-5 w-5 text-[#a3e635]" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">Our Story</h3>
                    <p className="text-gray-400 text-sm">
                      SnapZ Cloud started with a simple mission: make hosting fast, affordable and accessible for everyone. Many developers and community owners struggle with slow or expensive platforms, so we built SnapZ Cloud to simplify infrastructure and make deployment effortless.
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="w-10 h-10 bg-[#1a221a] rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                    <Rocket className="h-5 w-5 text-[#a3e635]" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">Our Vision</h3>
                    <p className="text-gray-400 text-sm">
                      Our vision is to empower developers, gamers and communities with reliable infrastructure that is simple to use and affordable. With SnapZ Cloud, launching servers, bots and websites should feel effortless and scalable.
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap gap-3 mt-8">
                {['Minecraft Hosting', 'Discord Bot Hosting', 'Free Bot Hosting', 'Lavalink', 'VPS', 'Web Hosting'].map((tag) => (
                  <span
                    key={tag}
                    className="px-4 py-2 bg-[#1a221a] border border-[#1f291f] rounded-full text-sm text-gray-300"
                  >
                    <span className="w-2 h-2 bg-[#a3e635] rounded-full inline-block mr-2" />
                    {tag}
                  </span>
                ))}
              </div>
            </div>

            <div className="relative">
              <img
                src="/images/about-hero.jpg"
                alt="Our Journey"
                className="rounded-2xl w-full"
              />
              <div className="absolute bottom-4 left-4 right-4 bg-[#0a120a]/90 backdrop-blur-sm rounded-xl p-4">
                <div className="text-[#a3e635] text-sm font-medium mb-1">BUILT FOR COMMUNITIES</div>
                <div className="text-white font-semibold">Reliable infra with gamer-first speed.</div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
