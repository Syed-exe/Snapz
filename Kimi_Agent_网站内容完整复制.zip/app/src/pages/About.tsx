import { ArrowRight, Play, Zap, Shield, CloudSync, Globe, Cpu } from 'lucide-react';
import { Link } from 'react-router-dom';

const About = () => {
  const features = [
    {
      icon: Zap,
      title: 'Raw Performance',
      description: 'Unthrottled CPU cycles and dedicated resources. No noisy neighbors, just pure speed.',
    },
    {
      icon: Shield,
      title: 'Ironclad Security',
      description: 'Advanced DDoS mitigation and automated backups keep your data safe, always.',
      badges: ['ISO 27001', 'GDPR'],
    },
    {
      icon: CloudSync,
      title: 'Reliability',
      description: 'Redundant power, cooling, and network paths ensure we never go dark.',
      stat: '100%',
      statLabel: 'Global Low Latency',
    },
  ];

  const hardware = [
    { label: 'Processor', value: 'AMD Ryzen™ 9', subValue: '7950X Series' },
    { label: 'Memory', value: 'DDR5 ECC' },
    { label: 'Storage', value: 'NVMe Gen4' },
    { label: 'Network', value: '10 Gbps' },
  ];

  const locations = [
    { code: 'NYC', name: 'New York' },
    { code: 'LON', name: 'London' },
    { code: 'FRA', name: 'Frankfurt' },
    { code: 'SIN', name: 'Singapore' },
    { code: 'SYD', name: 'Sydney' },
  ];

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="relative min-h-[80vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-black via-[#0a0a0a] to-black" />
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-[#a3e635]/20 rounded-full blur-3xl" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center space-x-2 bg-[#a3e635]/10 text-[#a3e635] px-3 py-1 rounded-full text-sm mb-6">
                <span className="w-2 h-2 bg-[#a3e635] rounded-full" />
                <span>Est. 2023</span>
              </div>

              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6">
                The Future of Performance Hosting
              </h1>

              <p className="text-xl text-white/60 mb-8 max-w-lg">
                We are engineering the backbone of the next-generation internet. SnapZ Cloud empowers developers, gamers, and enterprises with bare-metal performance and cloud flexibility.
              </p>

              <div className="flex flex-wrap gap-4">
                <Link
                  to="/minecraft"
                  className="inline-flex items-center space-x-2 bg-[#a3e635] text-black px-6 py-3 rounded-full font-semibold hover:bg-[#84cc16] transition-colors"
                >
                  <span>Our Story</span>
                  <ArrowRight className="w-5 h-5" />
                </Link>
                <button className="inline-flex items-center space-x-2 border border-white/20 px-6 py-3 rounded-full font-semibold hover:bg-white/5 transition-colors">
                  <Play className="w-5 h-5" />
                  <span>Watch Reel</span>
                </button>
              </div>
            </div>

            <div className="hidden lg:flex justify-center">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-[#a3e635]/20 to-transparent rounded-3xl blur-2xl" />
                <div className="relative bg-[#0a0a0a] border border-white/10 rounded-3xl p-8">
                  <div className="text-center">
                    <p className="text-white/60 text-sm mb-2">GLOBAL UPTIME</p>
                    <p className="text-6xl font-bold text-[#a3e635]">99.998%</p>
                    <div className="flex justify-center mt-4 space-x-1">
                      {[1, 2, 3, 4, 5].map((i) => (
                        <div
                          key={i}
                          className="w-2 bg-[#a3e635] rounded-full"
                          style={{ height: `${20 + i * 8}px` }}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-24 bg-[#0a0a0a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-[#a3e635]/10 rounded-2xl mb-8">
            <span className="text-3xl">📜</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Forged in Code, Built for Speed
          </h2>
          <p className="text-white/60 text-lg leading-relaxed">
            SnapZ Cloud began as a frustration. In 2023, a small team of systems engineers and game developers realized that existing hosting solutions forced a compromise: Power or Simplicity. You could rarely have both. We set out to dismantle that choice. By combining enterprise-grade bare metal with a developer-first interface, we've created a home for those who refuse to settle. From Minecraft servers to AI training clusters, we power the dreamers.
          </p>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-24 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature) => (
              <div key={feature.title} className="bg-[#0a0a0a] border border-white/10 rounded-2xl p-8">
                <div className="inline-flex items-center justify-center w-14 h-14 bg-[#a3e635]/10 rounded-xl mb-6">
                  <feature.icon className="w-7 h-7 text-[#a3e635]" />
                </div>
                <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                <p className="text-white/60 mb-4">{feature.description}</p>
                {feature.badges && (
                  <div className="flex gap-2">
                    {feature.badges.map((badge) => (
                      <span key={badge} className="text-xs bg-white/5 px-2 py-1 rounded">
                        {badge}
                      </span>
                    ))}
                  </div>
                )}
                {feature.stat && (
                  <div className="mt-4">
                    <p className="text-3xl font-bold text-[#a3e635]">{feature.stat}</p>
                    <p className="text-white/60 text-sm">{feature.statLabel}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Hardware Specs */}
      <section className="py-24 bg-[#0a0a0a]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-[#a3e635]/10 rounded-2xl mb-6">
              <Cpu className="w-8 h-8 text-[#a3e635]" />
            </div>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Hardware</h2>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {hardware.map((item) => (
              <div key={item.label} className="bg-black border border-white/10 rounded-2xl p-6 text-center">
                <p className="text-white/60 text-sm mb-2">{item.label}</p>
                <p className="text-xl font-bold">{item.value}</p>
                {item.subValue && <p className="text-[#a3e635]">{item.subValue}</p>}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Global Locations */}
      <section className="py-24 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-[#a3e635]/10 rounded-2xl mb-6">
              <Globe className="w-8 h-8 text-[#a3e635]" />
            </div>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Global Low Latency</h2>
            <p className="text-white/60">
              Strategically placed data centers in 12 regions worldwide.
            </p>
          </div>

          <div className="flex flex-wrap justify-center gap-4">
            {locations.map((location) => (
              <div
                key={location.code}
                className="bg-[#0a0a0a] border border-white/10 rounded-xl px-6 py-4"
              >
                <p className="text-2xl font-bold text-[#a3e635]">{location.code}</p>
                <p className="text-white/60 text-sm">{location.name}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
