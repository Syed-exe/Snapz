import { Lock } from 'lucide-react';

const PrivacyPolicy = () => {
  const sections = [
    {
      title: '1. Information We Collect',
      content: `When you use SnapZ Cloud services, we may collect the following types of information:

Personal Information:
Name, email address, billing address, and payment details when you register for an account or purchase a service.

Usage Data:
Information on how you interact with our website and services, including IP addresses, browser types, log files, and timestamps.

Cookies:
We use cookies to store session information, remember your preferences, and maintain account security.

Server Data:
We do not actively monitor the contents of your hosted servers, but we may scan for malware or prohibited content in accordance with our terms of service.`,
    },
    {
      title: '2. How We Use Your Information',
      content: `We use the collected information for various purposes, including:

• To provide, operate, and maintain our hosting services.
• To process transactions and send related information, including confirmations and invoices.
• To manage your account and provide customer support.
• To detect, prevent, and address technical issues or fraudulent activities.
• To communicate with you about updates, security alerts, and administrative messages.
• To improve our services and develop new features.`,
    },
    {
      title: '3. Data Sharing & Disclosure',
      content: `We do not sell or rent your personal information to third parties. We may share your data in the following circumstances:

Service Providers:
We share information with trusted third-party vendors (like payment processors and DDoS protection services) who assist us in operating our business.

Legal Compliance:
We may disclose information if required by law, court order, or governmental regulation, or to protect the rights, property, or safety of SnapZ Cloud, our users, or others.

Business Transfers:
If SnapZ Cloud is involved in a merger, acquisition, or sale of assets, your information may be transferred as part of that transaction.`,
    },
    {
      title: '4. Data Security',
      content: `We implement appropriate technical and organizational measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction.

These measures include:
• Encryption of sensitive data in transit and at rest.
• Regular security audits and vulnerability assessments.
• Strict access controls for our staff.
• Regular backup procedures to prevent data loss.

However, no method of transmission over the Internet or electronic storage is 100% secure. While we strive to use commercially acceptable means to protect your personal information, we cannot guarantee its absolute security.`,
    },
    {
      title: '5. Your Rights',
      content: `Depending on your location, you may have the following rights regarding your personal information:

• Access: Request a copy of the personal information we hold about you.
• Correction: Request that we correct any inaccurate or incomplete information.
• Deletion: Request that we delete your personal information in certain circumstances.
• Restriction: Request that we restrict the processing of your information.
• Portability: Request a copy of your data in a structured, machine-readable format.
• Objection: Object to the processing of your personal information for certain purposes.

To exercise any of these rights, please contact us through our support channels.`,
    },
    {
      title: '6. Data Retention',
      content: `We retain your personal information only for as long as necessary to fulfill the purposes outlined in this Privacy Policy, unless a longer retention period is required or permitted by law.

When you delete your account:
• We will delete your personal information within 30 days, except where we are legally required to retain it.
• Server data and backups may be retained for up to 90 days after service termination.
• Financial records may be retained for up to 7 years as required by tax laws.`,
    },
    {
      title: '7. Children\'s Privacy',
      content: `Our services are not intended for use by children under the age of 13. We do not knowingly collect personal information from children under 13. If we become aware that we have collected personal information from a child under 13, we will take steps to delete that information.

If you are a parent or guardian and believe your child has provided us with personal information, please contact us immediately.`,
    },
    {
      title: '8. Changes to This Privacy Policy',
      content: `We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Effective Date" at the top.

You are advised to review this Privacy Policy periodically for any changes. Changes to this Privacy Policy are effective when they are posted on this page.

If we make material changes to this Privacy Policy, we will notify you either through the email address you have provided us or by placing a prominent notice on our website.`,
    },
    {
      title: '9. Contact Us',
      content: `If you have any questions about this Privacy Policy or our data practices, please contact us:

• Through our Discord support server
• By email: privacy@snapzcloud.in
• Through our support ticket system

We will respond to your inquiry within 48 hours.`,
    },
  ];

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="relative py-24 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-black via-[#0a0a0a] to-black" />
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-[#a3e635]/20 rounded-full blur-3xl" />
        </div>

        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center space-x-2 bg-white/5 px-4 py-2 rounded-full text-sm mb-6">
            <span className="w-2 h-2 bg-[#a3e635] rounded-full" />
            <span>Effective Date: March 24, 2026</span>
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4">
            Privacy <span className="text-[#a3e635]">Policy</span>
          </h1>
          <p className="text-white/60 max-w-2xl mx-auto">
            Your privacy is critically important to us. This policy explains what information we collect, how we use it, and your rights.
          </p>
          <button className="mt-8 inline-flex items-center space-x-2 bg-white/5 border border-white/10 px-6 py-3 rounded-full font-semibold hover:bg-white/10 transition-colors">
            <Lock className="w-5 h-5" />
            <span>Privacy Controls</span>
          </button>
        </div>
      </section>

      {/* Content Section */}
      <section className="py-16 bg-black">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-[#0a0a0a] border border-white/10 rounded-3xl p-8 md:p-12">
            <div className="space-y-8">
              {sections.map((section, index) => (
                <div key={index} className="border-t border-white/10 pt-8 first:border-t-0 first:pt-0">
                  <h2 className="text-xl font-bold mb-4 flex items-center">
                    <span className="text-[#a3e635] mr-2">#</span>
                    {section.title}
                  </h2>
                  <div className="text-white/60 whitespace-pre-line leading-relaxed">
                    {section.content}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default PrivacyPolicy;
