import { Download } from 'lucide-react';

const TermsOfService = () => {
  const sections = [
    {
      title: '1. Acceptance of Terms',
      content: `Welcome to SnapZ Cloud. By using our hosting services, VPS solutions, or any related products, you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use our services.

We reserve the right to update and change the Terms of Service from time to time without notice. Any new features that augment or enhance the current Service, including the release of new tools and resources, shall be subject to the Terms of Service. Continued use of the Service after any such changes shall constitute your consent to such changes.`,
    },
    {
      title: '2. User Responsibilities & Acceptable Use',
      content: `You agree not to use the Service for any unlawful purpose or in any way that interrupts, damages, or impairs the service. You are responsible for all content posted and activity that occurs under your account.

Prohibited activities include, but are not limited to:
• Hosting of malicious software, scripts, phishing sites, or botnets.
• Sending unsolicited bulk email (SPAM) or hosting spam-supporting software.
• Unauthorized access to other computers, networks, or user accounts (hacking).
• Distribution of copyrighted material without permission or proper licensing.
• Crypto-mining activities on shared or VPS resources without explicit dedicated agreement.
• Any activity that violates applicable local, state, national, or international laws.`,
    },
    {
      title: '3. Billing, Payments & Refunds',
      content: `All services are billed in advance on a monthly or quarterly basis. Payment is due on the renewal date of your service. Failure to pay within 24 hours of the due date may result in service suspension.

We offer a 48-hour money-back guarantee for new customers. Refunds are only granted if:
• The request is made within 48 hours of the initial purchase.
• The service has not been misused or abused.
• The issue is confirmed to be caused by our infrastructure.

Non-refundable items include: setup fees, domain registrations, and third-party licenses.`,
    },
    {
      title: '4. Service Level Agreement (SLA)',
      content: `SnapZ Cloud aims to provide 99.9% uptime for all services. In the event that we fail to meet this guarantee, affected customers may be eligible for service credits as follows:
• 99.0% - 99.8% uptime: 10% credit
• 95.0% - 98.9% uptime: 25% credit
• Below 95.0% uptime: 50% credit

Credits must be requested within 7 days of the incident and will be applied to your next billing cycle.`,
    },
    {
      title: '5. Data Backup & Loss',
      content: `While we perform regular backups of our infrastructure, you are responsible for maintaining your own backups of critical data. SnapZ Cloud is not liable for any data loss that may occur.

We recommend:
• Regularly downloading backups of your important files.
• Using our automated backup features where available.
• Testing your backups periodically to ensure they can be restored.`,
    },
    {
      title: '6. Termination',
      content: `You may terminate your account at any time by canceling your services through the control panel or by contacting support. No refunds will be provided for prepaid services beyond the 48-hour money-back guarantee period.

We reserve the right to terminate or suspend your account immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms of Service.`,
    },
    {
      title: '7. Limitation of Liability',
      content: `In no event shall SnapZ Cloud, nor its directors, employees, partners, agents, suppliers, or affiliates, be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting from:
• Your access to or use of or inability to access or use the Service.
• Any conduct or content of any third party on the Service.
• Any content obtained from the Service.
• Unauthorized access, use or alteration of your transmissions or content.`,
    },
    {
      title: '8. Governing Law',
      content: `These Terms shall be governed and construed in accordance with the laws of India, without regard to its conflict of law provisions.

Our failure to enforce any right or provision of these Terms will not be considered a waiver of those rights. If any provision of these Terms is held to be invalid or unenforceable by a court, the remaining provisions of these Terms will remain in effect.`,
    },
  ];

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="relative py-24 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-black via-[#0a0a0a] to-black" />
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-[#a3e635]/20 rounded-full blur-3xl" />
        </div>

        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center space-x-2 bg-white/5 px-4 py-2 rounded-full text-sm mb-6">
            <span className="w-2 h-2 bg-[#a3e635] rounded-full" />
            <span>Effective Date: March 24, 2026</span>
          </div>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4">
            Terms of <span className="text-[#a3e635]">Service</span>
          </h1>
          <p className="text-white/60 max-w-2xl mx-auto">
            Please read these terms carefully before using SnapZ Cloud services. They define the legal relationship between you and SnapZ Cloud.
          </p>
          <button className="mt-8 inline-flex items-center space-x-2 bg-[#a3e635] text-black px-6 py-3 rounded-full font-semibold hover:bg-[#84cc16] transition-colors">
            <Download className="w-5 h-5" />
            <span>Download PDF Version</span>
          </button>
        </div>
      </section>

      {/* Content Section */}
      <section className="py-16 bg-black">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-[#0a0a0a] border border-white/10 rounded-3xl p-8 md:p-12">
            <p className="text-white/60 mb-8 leading-relaxed">
              By accessing or using the SnapZ Cloud website, hosting services, or any related applications (collectively, the "Service"), you agree to be bound by these Terms of Service ("Terms"). If you disagree with any part of the terms, then you may not access the Service.
            </p>

            <div className="space-y-8">
              {sections.map((section, index) => (
                <div key={index} className="border-t border-white/10 pt-8 first:border-t-0 first:pt-0">
                  <h2 className="text-xl font-bold mb-4 flex items-center">
                    <span className="text-[#a3e635] mr-2">#</span>
                    {section.title}
                  </h2>
                  <div className="text-white/60 whitespace-pre-line leading-relaxed">
                    {section.content}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default TermsOfService;
