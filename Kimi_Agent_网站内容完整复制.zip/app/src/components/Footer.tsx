import { Link } from 'react-router-dom';
import { ArrowUpRight, CheckCircle2 } from 'lucide-react';

const Footer = () => {
  const hostingLinks = [
    { name: 'VPS Servers', path: '/vps' },
    { name: 'Minecraft Hosting', path: '/minecraft' },
    { name: 'Discord Bots', path: '/bots' },
    { name: 'Web Hosting', path: '/web' },
    { name: 'Lavalink', path: '/lavalink' },
  ];

  const companyLinks = [
    { name: 'About Us', path: '/about' },
    { name: 'Guides', path: '/guides' },
    { name: 'Changelog', path: '/changelog' },
    { name: 'System Status', path: '/status' },
    { name: 'Contact Support', path: '/support' },
    { name: 'Careers', path: '/careers', badge: 'HIRING' },
  ];

  const legalLinks = [
    { name: 'Terms of Service', path: '/terms-of-service' },
    { name: 'Privacy Policy', path: '/privacy-policy' },
    { name: 'Refund Policy', path: '/refund-policy' },
  ];

  return (
    <footer className="bg-[#030803] border-t border-[#1f291f]">
      {/* CTA Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Start Your Game <span className="gradient-text">Server Today</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto mb-8">
            Get your ARK, Rust, Project Zomboid, Valheim and many more games set up and ready to play within 5 minutes with a click of a button.
          </p>
          <a
            href="https://discord.com/channels/1361725951607832718/1484182477697192166"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center px-8 py-4 bg-[#a3e635] text-[#030803] rounded-full font-semibold hover:bg-[#8ed62a] transition-colors btn-shine"
          >
            Rent your server
            <ArrowUpRight className="ml-2 h-5 w-5" />
          </a>
        </div>
      </div>

      {/* Main Footer */}
      <div className="border-t border-[#1f291f]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
            {/* Brand */}
            <div className="lg:col-span-2">
              <Link to="/" className="flex items-center space-x-2 mb-4">
                <img src="/images/logo.png" alt="SnapZ Cloud" className="h-8 w-auto" />
                <span className="text-xl font-bold">SnapZ Cloud</span>
              </Link>
              <p className="text-gray-400 text-sm max-w-xs">
                High-performance infrastructure built for creators, communities, and teams that need predictable speed 24/7.
              </p>
              <div className="flex space-x-4 mt-6">
                <a
                  href="https://discord.gg/MsvNYeQxCa"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-[#1a221a] flex items-center justify-center text-gray-400 hover:text-[#a3e635] hover:bg-[#1f291f] transition-colors"
                >
                  <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z" />
                  </svg>
                </a>
                <a
                  href="https://twitter.com/snapzcloud"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-[#1a221a] flex items-center justify-center text-gray-400 hover:text-[#a3e635] hover:bg-[#1f291f] transition-colors"
                >
                  <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                  </svg>
                </a>
              </div>
            </div>

            {/* Hosting Links */}
            <div>
              <h3 className="text-[#a3e635] font-semibold text-sm uppercase tracking-wider mb-4">Hosting</h3>
              <ul className="space-y-3">
                {hostingLinks.map((link) => (
                  <li key={link.path}>
                    <Link
                      to={link.path}
                      className="text-gray-400 hover:text-white text-sm transition-colors"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Company Links */}
            <div>
              <h3 className="text-[#a3e635] font-semibold text-sm uppercase tracking-wider mb-4">Company</h3>
              <ul className="space-y-3">
                {companyLinks.map((link) => (
                  <li key={link.path}>
                    <Link
                      to={link.path}
                      className="text-gray-400 hover:text-white text-sm transition-colors inline-flex items-center"
                    >
                      {link.name}
                      {link.badge && (
                        <span className="ml-2 px-2 py-0.5 bg-[#a3e635] text-[#030803] text-xs rounded-full font-medium">
                          {link.badge}
                        </span>
                      )}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Legal Links */}
            <div>
              <h3 className="text-[#a3e635] font-semibold text-sm uppercase tracking-wider mb-4">Legal</h3>
              <ul className="space-y-3">
                {legalLinks.map((link) => (
                  <li key={link.path}>
                    <Link
                      to={link.path}
                      className="text-gray-400 hover:text-white text-sm transition-colors"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-[#1f291f]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
            <p className="text-gray-500 text-sm">
              &copy; {new Date().getFullYear()} SnapZ Cloud Inc. All rights reserved.
            </p>
            <Link
              to="/status"
              className="inline-flex items-center text-gray-400 hover:text-[#a3e635] text-sm transition-colors"
            >
              <CheckCircle2 className="mr-2 h-4 w-4 text-[#a3e635]" />
              All systems operational
            </Link>
          </div>
          <div className="mt-4 text-center">
            <p className="text-gray-600 text-xs">
              Powered By Snap Zone | Designed By Snapz Development
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
