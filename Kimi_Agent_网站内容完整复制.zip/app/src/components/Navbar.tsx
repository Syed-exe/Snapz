import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ChevronDown, Menu, X, ArrowUpRight } from 'lucide-react';

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isHostingOpen, setIsHostingOpen] = useState(false);
  const [isImportantOpen, setIsImportantOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const isActive = (path: string) => location.pathname === path;

  const hostingLinks = [
    { name: 'Minecraft Hosting', path: '/minecraft', icon: '🎮' },
    { name: 'Discord Bots', path: '/bots', icon: '🤖' },
    { name: 'Lavalink', path: '/lavalink', icon: '🎵' },
    { name: 'VPS Servers', path: '/vps', icon: '☁️' },
  ];

  const importantLinks = [
    { name: 'Terms of Service', path: '/terms-of-service' },
    { name: 'Privacy Policy', path: '/privacy-policy' },
    { name: 'Refund Policy', path: '/refund-policy' },
    { name: 'Changelog', path: '/changelog' },
  ];

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'glass border-b border-[#1f291f]' : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <img src="/images/logo.png" alt="SnapZ Cloud" className="h-8 w-auto" />
            <span className="text-xl font-bold">SnapZ Cloud</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-1">
            <Link
              to="/"
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                isActive('/') ? 'text-[#a3e635]' : 'text-gray-300 hover:text-white'
              }`}
            >
              Home
            </Link>

            {/* Hosting Dropdown */}
            <div className="relative">
              <button
                onClick={() => setIsHostingOpen(!isHostingOpen)}
                onMouseEnter={() => setIsHostingOpen(true)}
                className="flex items-center px-4 py-2 rounded-lg text-sm font-medium text-gray-300 hover:text-white transition-colors"
              >
                Hosting
                <ChevronDown className={`ml-1 h-4 w-4 transition-transform ${isHostingOpen ? 'rotate-180' : ''}`} />
              </button>
              {isHostingOpen && (
                <div
                  onMouseLeave={() => setIsHostingOpen(false)}
                  className="absolute top-full left-0 mt-2 w-56 bg-[#0a120a] border border-[#1f291f] rounded-xl shadow-xl overflow-hidden animate-fade-in"
                >
                  {hostingLinks.map((link) => (
                    <Link
                      key={link.path}
                      to={link.path}
                      onClick={() => setIsHostingOpen(false)}
                      className="flex items-center px-4 py-3 text-sm text-gray-300 hover:text-white hover:bg-[#1a221a] transition-colors"
                    >
                      <span className="mr-3">{link.icon}</span>
                      {link.name}
                    </Link>
                  ))}
                </div>
              )}
            </div>

            <Link
              to="/status"
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                isActive('/status') ? 'text-[#a3e635]' : 'text-gray-300 hover:text-white'
              }`}
            >
              Status
            </Link>

            {/* Important Dropdown */}
            <div className="relative">
              <button
                onClick={() => setIsImportantOpen(!isImportantOpen)}
                onMouseEnter={() => setIsImportantOpen(true)}
                className="flex items-center px-4 py-2 rounded-lg text-sm font-medium text-gray-300 hover:text-white transition-colors"
              >
                Important
                <ChevronDown className={`ml-1 h-4 w-4 transition-transform ${isImportantOpen ? 'rotate-180' : ''}`} />
              </button>
              {isImportantOpen && (
                <div
                  onMouseLeave={() => setIsImportantOpen(false)}
                  className="absolute top-full left-0 mt-2 w-56 bg-[#0a120a] border border-[#1f291f] rounded-xl shadow-xl overflow-hidden animate-fade-in"
                >
                  {importantLinks.map((link) => (
                    <Link
                      key={link.path}
                      to={link.path}
                      onClick={() => setIsImportantOpen(false)}
                      className="block px-4 py-3 text-sm text-gray-300 hover:text-white hover:bg-[#1a221a] transition-colors"
                    >
                      {link.name}
                    </Link>
                  ))}
                </div>
              )}
            </div>

            <Link
              to="/about"
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                isActive('/about') ? 'text-[#a3e635]' : 'text-gray-300 hover:text-white'
              }`}
            >
              About Us
            </Link>
          </div>

          {/* Login Button */}
          <div className="hidden md:block">
            <Link
              to="/login"
              className="inline-flex items-center px-5 py-2 bg-[#a3e635] text-[#030803] rounded-full text-sm font-semibold hover:bg-[#8ed62a] transition-colors"
            >
              <ArrowUpRight className="mr-2 h-4 w-4" />
              Login
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden p-2 rounded-lg text-gray-300 hover:text-white"
          >
            {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-[#1f291f] animate-slide-in">
            <div className="space-y-2">
              <Link
                to="/"
                onClick={() => setIsMobileMenuOpen(false)}
                className="block px-4 py-2 rounded-lg text-gray-300 hover:text-white hover:bg-[#1a221a]"
              >
                Home
              </Link>
              <div className="px-4 py-2 text-gray-500 text-sm font-medium">Hosting</div>
              {hostingLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="block px-8 py-2 text-gray-300 hover:text-white"
                >
                  {link.name}
                </Link>
              ))}
              <Link
                to="/status"
                onClick={() => setIsMobileMenuOpen(false)}
                className="block px-4 py-2 rounded-lg text-gray-300 hover:text-white hover:bg-[#1a221a]"
              >
                Status
              </Link>
              <div className="px-4 py-2 text-gray-500 text-sm font-medium">Important</div>
              {importantLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="block px-8 py-2 text-gray-300 hover:text-white"
                >
                  {link.name}
                </Link>
              ))}
              <Link
                to="/about"
                onClick={() => setIsMobileMenuOpen(false)}
                className="block px-4 py-2 rounded-lg text-gray-300 hover:text-white hover:bg-[#1a221a]"
              >
                About Us
              </Link>
              <Link
                to="/login"
                onClick={() => setIsMobileMenuOpen(false)}
                className="block px-4 py-2 mt-4 bg-[#a3e635] text-[#030803] rounded-lg text-center font-semibold"
              >
                Login
              </Link>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
