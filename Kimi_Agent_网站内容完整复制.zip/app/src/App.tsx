import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Home from './pages/Home';
import Minecraft from './pages/Minecraft';
import DiscordBots from './pages/DiscordBots';
import Lavalink from './pages/Lavalink';
import VPS from './pages/VPS';
import About from './pages/About';
import Login from './pages/Login';
import Guides from './pages/Guides';
import Changelog from './pages/Changelog';
import TermsOfService from './pages/TermsOfService';
import PrivacyPolicy from './pages/PrivacyPolicy';
import RefundPolicy from './pages/RefundPolicy';
import Status from './pages/Status';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-[#030803] text-white">
        <Navbar />
        <main>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/minecraft" element={<Minecraft />} />
            <Route path="/bots" element={<DiscordBots />} />
            <Route path="/lavalink" element={<Lavalink />} />
            <Route path="/vps" element={<VPS />} />
            <Route path="/about" element={<About />} />
            <Route path="/login" element={<Login />} />
            <Route path="/guides" element={<Guides />} />
            <Route path="/changelog" element={<Changelog />} />
            <Route path="/terms-of-service" element={<TermsOfService />} />
            <Route path="/privacy-policy" element={<PrivacyPolicy />} />
            <Route path="/refund-policy" element={<RefundPolicy />} />
            <Route path="/status" element={<Status />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
